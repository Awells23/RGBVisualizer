package com.example.onlineshoppingapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //find button and attach onclick listener
        Button calculateButton = (Button) findViewById(R.id.calculateButton);
        calculateButton.setOnClickListener(buttonListener);
    }

    //Buttonlistener to catch button click events
    private View.OnClickListener buttonListener = new View.OnClickListener() {
        public void onClick(View v) {
                NumberFormat money = NumberFormat.getCurrencyInstance();
            //Grab double value input by user for price
            EditText priceText = (EditText) findViewById(R.id.inputPrice);
            String priceString = priceText.getText().toString();
            Double price = Double.parseDouble(priceString);


            //Get warranty value based on user input
            ToggleButton warrantyButton = (ToggleButton) findViewById(R.id.toggleWarranty);
            double warranty = 0.0;
            if (warrantyButton.isChecked()) {
                warranty = (price * .10);//if it is checked the warranty is equal to 10% of price
            } else
                warranty = 0.0;//otherwise no warranty cost

            //get double value for insurance
            Switch insuranceSwitch = (Switch) findViewById(R.id.switchInsurance);
            double insurance = 0.0;
            if (insuranceSwitch.isChecked()) {
                insurance = price * .05;//if insurance switch is checked insurance is equal to 5% of price
            } else
                insurance = 0.0;//otherwise no insurance cost

            //get double value for delivery from spinner
            Spinner spinnerDelivery = (Spinner) findViewById(R.id.spinnerDelivery);
            String delivery = (String) spinnerDelivery.getSelectedItem();

            double deliveryPrice = 0.0;//initialize price
            if (delivery.equals("Next day"))
                deliveryPrice = 20.0;
            else if (delivery.equals("Second day"))
                deliveryPrice = 10.0;
            else
                deliveryPrice = 5.0;//if they choose the string equal to next day or second day, otherwise shipping is $5

            //create calculator object and Set values for calculating total method
            Calculator gc = new Calculator();
            gc.setPrice(price);
            gc.setWarranty(warranty);
            gc.setInsurnace(insurance);
            gc.setDelivery(deliveryPrice);

            double total = gc.getTotal(price, warranty, insurance, deliveryPrice);//calculate
            //Get textview and set output
            TextView outputText = (TextView) findViewById(R.id.outputText);
            outputText.setText("" + money.format(total));
        }
    };
}