package com.example.onlineshoppingapplication;

public class Calculator {
    double price;
    double warranty;
    double insurance;
    double delivery;

    public void calculator() {
        price = 0.0;
        warranty = 0.0;
        insurance = 0.0;
        delivery = 0.0;
    }
    //setter methods to set variables for calculating the total
    public void setPrice(double price) {
        this.price = price;
    }

    public void setWarranty(double warranty) {
        this.warranty = warranty;
    }

    public void setInsurnace(double insurance) {
        this.insurance = insurance;
    }

    public void setDelivery(double delivery) {
        this.delivery = delivery;
    }
    //method for calculating total used to set output
    public double getTotal(double price, double warranty, double insurance, double delivery) {
        double total = price + warranty + insurance + delivery;
        return total;
    }
}
